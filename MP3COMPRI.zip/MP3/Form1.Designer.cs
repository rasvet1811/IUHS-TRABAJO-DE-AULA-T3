﻿namespace MP3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnPreview = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.bntPlay = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.P_Bar = new System.Windows.Forms.ProgressBar();
            this.TrackList = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.track_Volume = new System.Windows.Forms.TrackBar();
            this.lblVolume = new System.Windows.Forms.Label();
            this.lblTrack_Start = new System.Windows.Forms.Label();
            this.lbl_TrackEnd = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblVolu = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.aleatorio = new System.Windows.Forms.Button();
            this.textobusqueda = new System.Windows.Forms.TextBox();
            this.busca = new System.Windows.Forms.Button();
            this.Player = new AxWMPLib.AxWindowsMediaPlayer();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.track_Volume)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPreview
            // 
            this.btnPreview.Location = new System.Drawing.Point(39, 372);
            this.btnPreview.Margin = new System.Windows.Forms.Padding(2);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(50, 21);
            this.btnPreview.TabIndex = 0;
            this.btnPreview.Text = "Preview";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(100, 372);
            this.btnNext.Margin = new System.Windows.Forms.Padding(2);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(50, 21);
            this.btnNext.TabIndex = 1;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // bntPlay
            // 
            this.bntPlay.Location = new System.Drawing.Point(154, 372);
            this.bntPlay.Margin = new System.Windows.Forms.Padding(2);
            this.bntPlay.Name = "bntPlay";
            this.bntPlay.Size = new System.Drawing.Size(50, 21);
            this.bntPlay.TabIndex = 2;
            this.bntPlay.Text = "Play";
            this.bntPlay.UseVisualStyleBackColor = true;
            this.bntPlay.Click += new System.EventHandler(this.bntPlay_Click);
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(222, 372);
            this.btnPause.Margin = new System.Windows.Forms.Padding(2);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(50, 21);
            this.btnPause.TabIndex = 3;
            this.btnPause.Text = "Pause";
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(358, 372);
            this.btnOpen.Margin = new System.Windows.Forms.Padding(2);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(50, 21);
            this.btnOpen.TabIndex = 5;
            this.btnOpen.Text = "Open";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // P_Bar
            // 
            this.P_Bar.Location = new System.Drawing.Point(39, 348);
            this.P_Bar.Margin = new System.Windows.Forms.Padding(2);
            this.P_Bar.Name = "P_Bar";
            this.P_Bar.Size = new System.Drawing.Size(363, 15);
            this.P_Bar.TabIndex = 6;
            this.P_Bar.Click += new System.EventHandler(this.P_Bar_Click);
            this.P_Bar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.P_Bar_MouseDown);
            // 
            // TrackList
            // 
            this.TrackList.BackColor = System.Drawing.SystemColors.ControlLight;
            this.TrackList.ForeColor = System.Drawing.SystemColors.ControlText;
            this.TrackList.FormattingEnabled = true;
            this.TrackList.Location = new System.Drawing.Point(132, 251);
            this.TrackList.Margin = new System.Windows.Forms.Padding(2);
            this.TrackList.Name = "TrackList";
            this.TrackList.Size = new System.Drawing.Size(264, 82);
            this.TrackList.TabIndex = 7;
            this.TrackList.SelectedIndexChanged += new System.EventHandler(this.TrackList_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(13, 258);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(29, 75);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // track_Volume
            // 
            this.track_Volume.Location = new System.Drawing.Point(398, 236);
            this.track_Volume.Margin = new System.Windows.Forms.Padding(2);
            this.track_Volume.Maximum = 100;
            this.track_Volume.Name = "track_Volume";
            this.track_Volume.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.track_Volume.Size = new System.Drawing.Size(45, 81);
            this.track_Volume.TabIndex = 10;
            this.track_Volume.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.track_Volume.Scroll += new System.EventHandler(this.track_Volume_Scroll);
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.Location = new System.Drawing.Point(397, 319);
            this.lblVolume.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(42, 13);
            this.lblVolume.TabIndex = 11;
            this.lblVolume.Text = "Volume";
            // 
            // lblTrack_Start
            // 
            this.lblTrack_Start.AutoSize = true;
            this.lblTrack_Start.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTrack_Start.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTrack_Start.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTrack_Start.Location = new System.Drawing.Point(8, 14);
            this.lblTrack_Start.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTrack_Start.Name = "lblTrack_Start";
            this.lblTrack_Start.Size = new System.Drawing.Size(71, 26);
            this.lblTrack_Start.TabIndex = 12;
            this.lblTrack_Start.Text = "00:00";
            // 
            // lbl_TrackEnd
            // 
            this.lbl_TrackEnd.AutoSize = true;
            this.lbl_TrackEnd.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_TrackEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TrackEnd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_TrackEnd.Location = new System.Drawing.Point(325, 14);
            this.lbl_TrackEnd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_TrackEnd.Name = "lbl_TrackEnd";
            this.lbl_TrackEnd.Size = new System.Drawing.Size(71, 26);
            this.lbl_TrackEnd.TabIndex = 13;
            this.lbl_TrackEnd.Text = "00:00";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblVolu
            // 
            this.lblVolu.AutoSize = true;
            this.lblVolu.Location = new System.Drawing.Point(397, 221);
            this.lblVolu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblVolu.Name = "lblVolu";
            this.lblVolu.Size = new System.Drawing.Size(33, 13);
            this.lblVolu.TabIndex = 14;
            this.lblVolu.Text = "100%";
            this.lblVolu.Click += new System.EventHandler(this.lblVolu_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(413, 372);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(64, 21);
            this.button1.TabIndex = 15;
            this.button1.Text = "Remove";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // aleatorio
            // 
            this.aleatorio.Location = new System.Drawing.Point(483, 372);
            this.aleatorio.Name = "aleatorio";
            this.aleatorio.Size = new System.Drawing.Size(65, 21);
            this.aleatorio.TabIndex = 16;
            this.aleatorio.Text = "aleatorio";
            this.aleatorio.UseVisualStyleBackColor = true;
            this.aleatorio.Click += new System.EventHandler(this.aleatorio_Click);
            // 
            // textobusqueda
            // 
            this.textobusqueda.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textobusqueda.Location = new System.Drawing.Point(39, 398);
            this.textobusqueda.Name = "textobusqueda";
            this.textobusqueda.Size = new System.Drawing.Size(299, 20);
            this.textobusqueda.TabIndex = 17;
            this.textobusqueda.TextChanged += new System.EventHandler(this.textobusqueda_TextChanged);
            // 
            // busca
            // 
            this.busca.Location = new System.Drawing.Point(355, 396);
            this.busca.Name = "busca";
            this.busca.Size = new System.Drawing.Size(75, 23);
            this.busca.TabIndex = 18;
            this.busca.Text = "Buscar";
            this.busca.UseVisualStyleBackColor = true;
            this.busca.Click += new System.EventHandler(this.busca_Click);
            // 
            // Player
            // 
            this.Player.Dock = System.Windows.Forms.DockStyle.Top;
            this.Player.Enabled = true;
            this.Player.Location = new System.Drawing.Point(0, 0);
            this.Player.Margin = new System.Windows.Forms.Padding(2);
            this.Player.Name = "Player";
            this.Player.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Player.OcxState")));
            this.Player.Size = new System.Drawing.Size(604, 232);
            this.Player.TabIndex = 9;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(422, 348);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(80, 17);
            this.checkBox1.TabIndex = 19;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(604, 425);
            this.ControlBox = false;
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.busca);
            this.Controls.Add(this.textobusqueda);
            this.Controls.Add(this.aleatorio);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblVolu);
            this.Controls.Add(this.lbl_TrackEnd);
            this.Controls.Add(this.lblTrack_Start);
            this.Controls.Add(this.lblVolume);
            this.Controls.Add(this.track_Volume);
            this.Controls.Add(this.Player);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.TrackList);
            this.Controls.Add(this.P_Bar);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.bntPlay);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPreview);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MILAGRO";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.track_Volume)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button bntPlay;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.ProgressBar P_Bar;
        private System.Windows.Forms.ListBox TrackList;
        private System.Windows.Forms.PictureBox pictureBox1;
        private AxWMPLib.AxWindowsMediaPlayer Player;
        private System.Windows.Forms.TrackBar track_Volume;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.Label lblTrack_Start;
        private System.Windows.Forms.Label lbl_TrackEnd;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblVolu;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button aleatorio;
        private System.Windows.Forms.TextBox textobusqueda;
        private System.Windows.Forms.Button busca;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}

